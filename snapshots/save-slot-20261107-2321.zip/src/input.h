#ifndef INPUT_H
#define INPUT_H

/* Inotia 4 is a touch-only game: every control is drawn on screen and the
 * engine reads pointers. The Switch pad is therefore mapped onto synthetic
 * touch points, and the real touchscreen is forwarded unchanged. */

typedef struct {
  int inject;      /* mirror touches into the engine queue (see input.c) */
  int touch_x_pct; /* virtual dpad origin, percent of the view */
  int touch_y_pct;
  int button_pct;  /* action area radius, percent of the view */
} InputConfig;

struct so_module;

void input_init(int screen_w, int screen_h, struct so_module *mod);
/* resolve the engine's input queue once libgame.so is loaded */
void input_bind(struct so_module *mod);
/* must be called after so_finalize(): only then is that memory readable */
void input_set_base(void *virtbase);
void input_configure(const InputConfig *cfg);
void input_update(void);
void input_shutdown(void);

/* raw pointer feed, also used by the pad mapping */
void input_touch(int action, int id, float x, float y);

/* synthetic tap: press and release at once (screen coordinates) */
void input_tap_at(int x, int y);

/* where the pad's virtual finger is, so it can be drawn */
void input_cursor(int *x, int *y);

/* 1 while the pad is cycling menu targets instead of aiming freely */
int input_focus_mode(void);

/* top-left corner and size of the highlight box, in view pixels from the top */
void input_focus_box(int *x, int *y, int *w, int *h);

int  input_injection_active(void);

/* Vertical travel of the finger since the last call (screen pixels, positive =
 * moved down), drained on every call. Pages whose own scroll control never sees
 * the input (the skill description) use this to drive their scroll themselves. */
int input_take_drag_dy(void);

/* 1 while a finger is down, with the point it went down at (screen pixels).
 * A page only scrolls for a drag that started inside it, so that dragging the
 * skill tree does not also move the description next to it. */
int input_drag_start(float *x, float *y);

/* what the engine believes its screen size is (bring-up diagnostics) */
int input_engine_screen_w(void);
unsigned char *input_engine_virtbase(void);
int input_engine_screen_h(void);
/* the engine's live touch count (0 == no finger down) */
int input_engine_touch_count(void);

/* ------------------------------------------------------------------------- */
/* in-game HUD -> pad mapping                                                */
/*                                                                           */
/* The HUD rects are read from the engine's own control tree every few frames,
 * in engine layout units -- no screenshot measuring, no hard-coded pixels.
 * main.c calls begin/end around one walk of the tree; input.c converts the
 * rects through SGL_GetScreenWidth/Height when it injects a touch.           */
enum {
  HUD_BTN_PLUS = 0,   /* control id 1:  first button in the left column  */
  HUD_BTN_MINUS,      /* control id 3:  the gear                          */
  HUD_BTN_ACTION,     /* control id 20: the big disc, lower right         */
  HUD_DPAD,           /* control id 21: the virtual direction pad          */
  HUD_RECT_N
};
void input_hud_begin(void);
void input_set_hud_rect(int which, long x, long y, long w, long h);
/* the control object itself, so + / - / A can be fired on it directly instead
 * of through the single touch pointer (see hud_action in input.c) */
void input_set_hud_obj(int which, void *obj);
void input_hud_end(void);
int  input_hud_present(void);
/* 1 while a direction is being driven on the pad (used by the pad-zone probe) */
int  input_pad_held(void);

/* The × / back / skip button of the page on top, found in the engine's own
 * control tree. Returns its centre in engine units.
 * Return: 2 = a wide skip bar in the top-right, 1 = a × in the top-left,
 *         0 = nothing found. */
int  ui_corner_button(long *cx, long *cy);

#endif
